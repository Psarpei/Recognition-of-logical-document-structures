Use `test-cnn.cc` as a reference for how to set up subsequent tests.
