#ifndef CNN_GRAPH_H
#define CNN_GRAPH_H

namespace cnn {
struct ComputationGraph;
void GraphOptimize(ComputationGraph* cg);
} // namespace cnn

#endif
